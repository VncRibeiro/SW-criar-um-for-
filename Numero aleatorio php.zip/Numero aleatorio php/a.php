<?php

echo "<pre>";
$coelho = $_POST;
$aleatorio = array();

for($a=$coelho["resultado1"]; $a < $coelho["resultado2"]; $a++){


    $aleatorio[] = rand();

}
function parouimpar($sla)
{

if($sla % 2 == 0)
{
$que = true;
}
else
{
$que = false;
}
return $que;
}

foreach ($aleatorio as $key => $value) {
  echo $key . " O numero " . $value;
   if (parouimpar($value)) {
    echo " O par ";
  } else {
    echo " O Impar ";
  }
  echo "<br>";
}

?>
